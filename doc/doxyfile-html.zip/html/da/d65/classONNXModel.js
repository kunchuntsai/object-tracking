var classONNXModel =
[
    [ "ONNXModel", "da/d65/classONNXModel.html#a1272c9d3adc1da150c15bc50fe16937e", null ],
    [ "~ONNXModel", "da/d65/classONNXModel.html#a5ac3c9fa26bac5f3a6362d173f8c9641", null ],
    [ "ONNXModel", "da/d65/classONNXModel.html#a017b05c7a3c716076fd89d6e522d4c54", null ],
    [ "appendCoreMLExecutionProvider", "da/d65/classONNXModel.html#aa76a29cb4d1a6ba6b19c35ffa86f66c9", null ],
    [ "appendCUDAExecutionProvider", "da/d65/classONNXModel.html#ab12ebf2d02b1c3fd7fbb9f27ee179591", null ],
    [ "detect", "da/d65/classONNXModel.html#af4216ff7508e948065a82c8664038932", null ],
    [ "getInputNodeDims", "da/d65/classONNXModel.html#ae91e19c792f304ca3de16e7fe785e560", null ],
    [ "getInstance", "da/d65/classONNXModel.html#a59c8b0cdae6aae98b33f0ddd0273f435", null ],
    [ "getMemoryInfo", "da/d65/classONNXModel.html#acf6fb23e4ffdc6cbd6d9662015b87774", null ],
    [ "loadModel", "da/d65/classONNXModel.html#a533963212cff985864deae9018f93cdf", null ],
    [ "operator=", "da/d65/classONNXModel.html#ae8eda74f904af5b450aba943d483ad19", null ],
    [ "postprocess", "da/d65/classONNXModel.html#ad01a82dfeaa9f33fdb8a8e28b7dd71d8", null ],
    [ "allocator", "da/d65/classONNXModel.html#acd055301fc9505971dd8930cbe012223", null ],
    [ "env", "da/d65/classONNXModel.html#abd48fc5536ad7b4f81b7ec5e31b603cf", null ],
    [ "input_node_dims", "da/d65/classONNXModel.html#a018737ba47e5928cda47cb6154551375", null ],
    [ "input_node_names", "da/d65/classONNXModel.html#a9f64aa63cf2ebe204fc3af3fc1368d19", null ],
    [ "memory_info", "da/d65/classONNXModel.html#af1f379cd7aeecdf441e762257ab1b226", null ],
    [ "output_node_names", "da/d65/classONNXModel.html#aa68977c57de824ebff61bc440820e74b", null ],
    [ "session", "da/d65/classONNXModel.html#a3a6b18a21e7da3efdee34d4bdb1ebb05", null ],
    [ "session_options", "da/d65/classONNXModel.html#a6b6bb8dcbaf98ba9dcf27281913188e6", null ]
];