var config_8cc =
[
    [ "removeComment", "dd/da8/config_8cc.html#aca3ca3dab6bf687e09f5304efca3dc03", null ],
    [ "trim", "dd/da8/config_8cc.html#a8c7f671a4eaae43db4839df0abcb514a", null ]
];