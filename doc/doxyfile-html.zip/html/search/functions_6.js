var searchData=
[
  ['initialization_0',['initialization',['../d9/d0f/main_8cc.html#a64753b28ac7def0bf1b5f4e66b159ffb',1,'main.cc']]],
  ['initialize_1',['initialize',['../d2/dec/classFrameSource.html#ae6b62461c6ad11c95be2b8eb2afef520',1,'FrameSource']]]
];
