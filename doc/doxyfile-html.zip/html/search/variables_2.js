var searchData=
[
  ['detections_0',['detections',['../df/de6/structFrame.html#a45d5628402b8039228ae8bf65e2b53ae',1,'Frame']]]
];
