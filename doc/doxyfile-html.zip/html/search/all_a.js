var searchData=
[
  ['nexttrackid_0',['nextTrackID',['../d6/ddd/classTracker.html#a593cd7bbc5e393ab058de9365e135719',1,'Tracker']]],
  ['none_1',['NONE',['../db/d67/classLogger.html#ac744681e23720966b5f430ec2060da36ab50339a10e1de285ac99d4c3990b8693',1,'Logger']]],
  ['normalize_2',['normalize',['../de/de3/classImageProcessor.html#a5a6816dbeb50490284905e976512189e',1,'ImageProcessor']]]
];
