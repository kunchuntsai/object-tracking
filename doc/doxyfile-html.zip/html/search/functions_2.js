var searchData=
[
  ['detect_0',['detect',['../da/d65/classONNXModel.html#af4216ff7508e948065a82c8664038932',1,'ONNXModel']]],
  ['display_1',['Display',['../d6/dd6/classDisplay.html#ae972fffea6f7ca1d627ef48c3d841bb3',1,'Display']]]
];
