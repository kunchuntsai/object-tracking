var searchData=
[
  ['video_0',['VIDEO',['../d9/df9/classConfig.html#a5a02009ce4a8c21e9cf586d27bcebf43ae60ae31f67ab883c746bb71c7a145c18',1,'Config']]],
  ['videopath_1',['videoPath',['../d9/df9/classConfig.html#ae565c2a85cc21afbd5afc4d8373066fd',1,'Config']]]
];
