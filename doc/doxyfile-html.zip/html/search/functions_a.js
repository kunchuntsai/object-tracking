var searchData=
[
  ['onnxmodel_0',['ONNXModel',['../da/d65/classONNXModel.html#a1272c9d3adc1da150c15bc50fe16937e',1,'ONNXModel::ONNXModel()'],['../da/d65/classONNXModel.html#a017b05c7a3c716076fd89d6e522d4c54',1,'ONNXModel::ONNXModel(const ONNXModel &amp;)=delete']]],
  ['operator_3d_1',['operator=',['../df/de6/structFrame.html#a1d84bee1e3f22925f00461838f5ad075',1,'Frame::operator=(const Frame &amp;)=delete'],['../df/de6/structFrame.html#afe2cc956887b3ed3fe02b2f79eb25703',1,'Frame::operator=(Frame &amp;&amp;)=default'],['../d2/dec/classFrameSource.html#a4fd7fcd89d214d9552ce0375c03112d7',1,'FrameSource::operator=()'],['../da/d65/classONNXModel.html#ae8eda74f904af5b450aba943d483ad19',1,'ONNXModel::operator=()']]]
];
