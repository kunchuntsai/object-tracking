var searchData=
[
  ['none_0',['NONE',['../db/d67/classLogger.html#ac744681e23720966b5f430ec2060da36ab50339a10e1de285ac99d4c3990b8693',1,'Logger']]]
];
