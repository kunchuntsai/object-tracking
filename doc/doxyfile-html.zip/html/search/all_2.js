var searchData=
[
  ['debug_0',['DEBUG',['../db/d67/classLogger.html#ac744681e23720966b5f430ec2060da36adc30ec20708ef7b0f641ef78b7880a15',1,'Logger']]],
  ['detect_1',['detect',['../da/d65/classONNXModel.html#af4216ff7508e948065a82c8664038932',1,'ONNXModel']]],
  ['detections_2',['detections',['../df/de6/structFrame.html#a45d5628402b8039228ae8bf65e2b53ae',1,'Frame']]],
  ['display_3',['Display',['../d6/dd6/classDisplay.html',1,'Display'],['../d6/dd6/classDisplay.html#ae972fffea6f7ca1d627ef48c3d841bb3',1,'Display::Display()']]],
  ['display_2ecc_4',['display.cc',['../d5/d94/display_8cc.html',1,'']]],
  ['display_2eh_5',['display.h',['../d4/d68/display_8h.html',1,'']]]
];
