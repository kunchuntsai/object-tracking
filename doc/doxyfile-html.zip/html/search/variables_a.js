var searchData=
[
  ['processed_0',['processed',['../df/de6/structFrame.html#aaf3fae0ae9276b03fb48eb4ae7a50eec',1,'Frame']]]
];
