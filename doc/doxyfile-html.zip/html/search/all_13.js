var searchData=
[
  ['warning_0',['WARNING',['../db/d67/classLogger.html#ac744681e23720966b5f430ec2060da36a059e9861e0400dfbe05c98a841f3f96b',1,'Logger']]],
  ['windowname_1',['windowName',['../d6/dd6/classDisplay.html#a09a9867ca9494df661f2f7f23691340f',1,'Display']]]
];
