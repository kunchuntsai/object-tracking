var searchData=
[
  ['maxframestoskip_0',['maxFramesToSkip',['../d9/df9/classConfig.html#a133740f24136826012c6362cee11c653',1,'Config']]],
  ['memory_5finfo_1',['memory_info',['../da/d65/classONNXModel.html#af1f379cd7aeecdf441e762257ab1b226',1,'ONNXModel::memory_info'],['../df/daf/classPreprocessor.html#aa25b4d3472c9d3bc90c1c2031e9e0511',1,'Preprocessor::memory_info']]],
  ['modelpath_2',['modelPath',['../d9/df9/classConfig.html#a153a40796f285a973b406b498f514b00',1,'Config']]],
  ['mutex_3',['mutex',['../da/d7e/classThreadSafeQueue.html#ac15713986ff635257d18ae678cdd9f32',1,'ThreadSafeQueue']]]
];
