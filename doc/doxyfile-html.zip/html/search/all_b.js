var searchData=
[
  ['onnx_5finput_0',['onnx_input',['../df/de6/structFrame.html#a9603d0466b1e18c9507068219e748a58',1,'Frame']]],
  ['onnx_5fmodel_2ecc_1',['onnx_model.cc',['../d6/dd4/onnx__model_8cc.html',1,'']]],
  ['onnx_5fmodel_2eh_2',['onnx_model.h',['../d8/d6d/onnx__model_8h.html',1,'']]],
  ['onnxmodel_3',['ONNXModel',['../da/d65/classONNXModel.html',1,'ONNXModel'],['../da/d65/classONNXModel.html#a1272c9d3adc1da150c15bc50fe16937e',1,'ONNXModel::ONNXModel()'],['../da/d65/classONNXModel.html#a017b05c7a3c716076fd89d6e522d4c54',1,'ONNXModel::ONNXModel(const ONNXModel &amp;)=delete']]],
  ['operator_3d_4',['operator=',['../df/de6/structFrame.html#a1d84bee1e3f22925f00461838f5ad075',1,'Frame::operator=(const Frame &amp;)=delete'],['../df/de6/structFrame.html#afe2cc956887b3ed3fe02b2f79eb25703',1,'Frame::operator=(Frame &amp;&amp;)=default'],['../d2/dec/classFrameSource.html#a4fd7fcd89d214d9552ce0375c03112d7',1,'FrameSource::operator=()'],['../da/d65/classONNXModel.html#ae8eda74f904af5b450aba943d483ad19',1,'ONNXModel::operator=()']]],
  ['original_5',['original',['../df/de6/structFrame.html#a9ef2a789d9cb8aa76774f1ddea8c0be3',1,'Frame']]],
  ['output_5fnode_5fnames_6',['output_node_names',['../da/d65/classONNXModel.html#aa68977c57de824ebff61bc440820e74b',1,'ONNXModel']]],
  ['outputqueue_7',['outputQueue',['../df/daf/classPreprocessor.html#aa9734c3bd593c70db7ca958d1d677aff',1,'Preprocessor::outputQueue'],['../d6/ddd/classTracker.html#a5fa81d88daf04c61add924a21934d0a0',1,'Tracker::outputQueue']]]
];
