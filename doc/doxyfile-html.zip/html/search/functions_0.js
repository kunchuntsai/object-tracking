var searchData=
[
  ['appendcoremlexecutionprovider_0',['appendCoreMLExecutionProvider',['../da/d65/classONNXModel.html#aa76a29cb4d1a6ba6b19c35ffa86f66c9',1,'ONNXModel']]],
  ['appendcudaexecutionprovider_1',['appendCUDAExecutionProvider',['../da/d65/classONNXModel.html#ab12ebf2d02b1c3fd7fbb9f27ee179591',1,'ONNXModel']]]
];
