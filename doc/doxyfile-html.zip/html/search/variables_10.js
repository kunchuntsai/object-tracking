var searchData=
[
  ['windowname_0',['windowName',['../d6/dd6/classDisplay.html#a09a9867ca9494df661f2f7f23691340f',1,'Display']]]
];
