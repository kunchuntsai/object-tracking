var onnx__model_8cc =
[
    [ "INPUT_HEIGHT", "d6/dd4/onnx__model_8cc.html#aa6207d67116f4d07e73279c2d85ab0ef", null ],
    [ "INPUT_WIDTH", "d6/dd4/onnx__model_8cc.html#a3a42763433869192b35c7af211c2567c", null ]
];