var classTracker =
[
    [ "Track", "d4/df3/classTracker_1_1Track.html", "d4/df3/classTracker_1_1Track" ],
    [ "Tracker", "d6/ddd/classTracker.html#a5b6842df0690b723ac2c69240ec7b1c5", null ],
    [ "calculateIoU", "d6/ddd/classTracker.html#abea48d46660a6278df6c19a0a84e6748", null ],
    [ "getProcessedFrame", "d6/ddd/classTracker.html#a216c17db8cd5b4038a6e949b331e94f4", null ],
    [ "run", "d6/ddd/classTracker.html#a19703e1ea386e761a1286573e2cbb38b", null ],
    [ "updateTracks", "d6/ddd/classTracker.html#a5525a792929810aa7647663d78242557", null ],
    [ "inputQueue", "d6/ddd/classTracker.html#a1c511f161799138749fded7d94142366", null ],
    [ "nextTrackID", "d6/ddd/classTracker.html#a593cd7bbc5e393ab058de9365e135719", null ],
    [ "outputQueue", "d6/ddd/classTracker.html#a5fa81d88daf04c61add924a21934d0a0", null ],
    [ "tracks", "d6/ddd/classTracker.html#ac3418716b68ceffb07e2b88609adcffc", null ]
];