var main_8cc =
[
    [ "continuousMode", "d9/d0f/main_8cc.html#a8c4e53288c35c3c1782556edd100c6b9", null ],
    [ "frameCount", "d9/d0f/main_8cc.html#a5f526b1b39a4d4cec035c55aec5228cc", null ],
    [ "handleKeyboard", "d9/d0f/main_8cc.html#a16d6f583da338d5d5b1a467d9e787ae0", null ],
    [ "initialization", "d9/d0f/main_8cc.html#a64753b28ac7def0bf1b5f4e66b159ffb", null ],
    [ "main", "d9/d0f/main_8cc.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "printProfilingResults", "d9/d0f/main_8cc.html#ae734c2faba7813eab0eda3f7cf03ba10", null ],
    [ "shouldExit", "d9/d0f/main_8cc.html#aaf38792cc0c1d64d2bdfe0c8458176cf", null ],
    [ "totalMainTime", "d9/d0f/main_8cc.html#afddb489874eea2b22f985e26318b33e8", null ],
    [ "totalPreprocessTime", "d9/d0f/main_8cc.html#ad7cc840812a2f3a218027b36d19c50c1", null ],
    [ "totalTrackerTime", "d9/d0f/main_8cc.html#a4f16e379bbbc2a10aff72f1f33d97234", null ],
    [ "lastFPSUpdateTime", "d9/d0f/main_8cc.html#a29c9e1ffa81202764cb3a683adf9a6cc", null ],
    [ "realtimeFrameCount", "d9/d0f/main_8cc.html#a5908fdb2678c3c41458d379682d9b39d", null ],
    [ "totalFrameTime", "d9/d0f/main_8cc.html#af69f80306395fd139a58304512baa3f0", null ]
];