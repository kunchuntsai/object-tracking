var classConfig =
[
    [ "InputSource", "d9/df9/classConfig.html#a5a02009ce4a8c21e9cf586d27bcebf43", [
      [ "VIDEO", "d9/df9/classConfig.html#a5a02009ce4a8c21e9cf586d27bcebf43ae60ae31f67ab883c746bb71c7a145c18", null ],
      [ "CAMERA", "d9/df9/classConfig.html#a5a02009ce4a8c21e9cf586d27bcebf43addf0d6b21537d984fea6544f58101fa8", null ]
    ] ],
    [ "getConfidenceThreshold", "d9/df9/classConfig.html#ac438f61a51cb08737f8fb3f5fde5a4b4", null ],
    [ "getInputSource", "d9/df9/classConfig.html#a5a4ab4168449f0ce37d6944f97a1b520", null ],
    [ "getIoUThreshold", "d9/df9/classConfig.html#a528a80f10c282c764e063b5605f043a2", null ],
    [ "getLogLevelMask", "d9/df9/classConfig.html#af40018e640979dd0cdbe56375034c8bb", null ],
    [ "getMaxFramesToSkip", "d9/df9/classConfig.html#a567804ac10c6e256bf249b1ebcc38497", null ],
    [ "getModelPath", "d9/df9/classConfig.html#a98be2dcf2f2c592a82801719b1c1bb97", null ],
    [ "getVideoPath", "d9/df9/classConfig.html#a5e916d00127c5522110bee65961097b1", null ],
    [ "loadFromFile", "d9/df9/classConfig.html#ab3305c6a7fd1e0dbd550f4012feb6f0b", null ],
    [ "setInputSource", "d9/df9/classConfig.html#afc38ea239c948aa67c9b64c38931fc61", null ],
    [ "setVideoPath", "d9/df9/classConfig.html#a807bd2a6472ecc1c55315fab2d20151c", null ],
    [ "confidenceThreshold", "d9/df9/classConfig.html#a7bdb7a6de8bbc2c22e5dc0a5906e6324", null ],
    [ "inputSource", "d9/df9/classConfig.html#a5a5e77bf93c7330897d62f7bbbbc8cbf", null ],
    [ "iouThreshold", "d9/df9/classConfig.html#a932f032b04458d829a818ba16751fa46", null ],
    [ "logLevelMask", "d9/df9/classConfig.html#a0be45bff56049dabf444eea83f883214", null ],
    [ "maxFramesToSkip", "d9/df9/classConfig.html#a133740f24136826012c6362cee11c653", null ],
    [ "modelPath", "d9/df9/classConfig.html#a153a40796f285a973b406b498f514b00", null ],
    [ "videoPath", "d9/df9/classConfig.html#ae565c2a85cc21afbd5afc4d8373066fd", null ]
];