var annotated_dup =
[
    [ "Config", "d9/df9/classConfig.html", "d9/df9/classConfig" ],
    [ "Display", "d6/dd6/classDisplay.html", "d6/dd6/classDisplay" ],
    [ "Frame", "df/de6/structFrame.html", "df/de6/structFrame" ],
    [ "FrameSource", "d2/dec/classFrameSource.html", "d2/dec/classFrameSource" ],
    [ "ImageProcessor", "de/de3/classImageProcessor.html", "de/de3/classImageProcessor" ],
    [ "Logger", "db/d67/classLogger.html", "db/d67/classLogger" ],
    [ "ONNXModel", "da/d65/classONNXModel.html", "da/d65/classONNXModel" ],
    [ "Preprocessor", "df/daf/classPreprocessor.html", "df/daf/classPreprocessor" ],
    [ "ThreadSafeQueue", "da/d7e/classThreadSafeQueue.html", "da/d7e/classThreadSafeQueue" ],
    [ "Tracker", "d6/ddd/classTracker.html", "d6/ddd/classTracker" ]
];