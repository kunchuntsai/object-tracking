var classImageProcessor =
[
    [ "normalize", "de/de3/classImageProcessor.html#a5a6816dbeb50490284905e976512189e", null ],
    [ "preprocessForONNX", "de/de3/classImageProcessor.html#a7b0a78011610b2e9f3deeb7b165ad794", null ],
    [ "processFrame", "de/de3/classImageProcessor.html#a8207fe493c6c3eca09251f1dba0f203d", null ],
    [ "resize", "de/de3/classImageProcessor.html#ae2795070c91eca205d7aef4d91124629", null ]
];