var structFrame =
[
    [ "Frame", "df/de6/structFrame.html#af859480e7bdedf343c1ad7d941106f26", null ],
    [ "Frame", "df/de6/structFrame.html#a81b223464a73bef92d0ad712e0456bb8", null ],
    [ "Frame", "df/de6/structFrame.html#aea2b9c03ee8eafb462067b488179907f", null ],
    [ "operator=", "df/de6/structFrame.html#a1d84bee1e3f22925f00461838f5ad075", null ],
    [ "operator=", "df/de6/structFrame.html#afe2cc956887b3ed3fe02b2f79eb25703", null ],
    [ "detections", "df/de6/structFrame.html#a45d5628402b8039228ae8bf65e2b53ae", null ],
    [ "onnx_input", "df/de6/structFrame.html#a9603d0466b1e18c9507068219e748a58", null ],
    [ "original", "df/de6/structFrame.html#a9ef2a789d9cb8aa76774f1ddea8c0be3", null ],
    [ "processed", "df/de6/structFrame.html#aaf3fae0ae9276b03fb48eb4ae7a50eec", null ],
    [ "trackIDs", "df/de6/structFrame.html#ae3a015f7b83555e273b4ae26d531c69b", null ]
];