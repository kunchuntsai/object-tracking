var classLogger =
[
    [ "LogLevel", "db/d67/classLogger.html#ac744681e23720966b5f430ec2060da36", [
      [ "NONE", "db/d67/classLogger.html#ac744681e23720966b5f430ec2060da36ab50339a10e1de285ac99d4c3990b8693", null ],
      [ "ERROR", "db/d67/classLogger.html#ac744681e23720966b5f430ec2060da36abb1ca97ec761fc37101737ba0aa2e7c5", null ],
      [ "WARNING", "db/d67/classLogger.html#ac744681e23720966b5f430ec2060da36a059e9861e0400dfbe05c98a841f3f96b", null ],
      [ "INFO", "db/d67/classLogger.html#ac744681e23720966b5f430ec2060da36a551b723eafd6a31d444fcb2f5920fbd3", null ],
      [ "DEBUG", "db/d67/classLogger.html#ac744681e23720966b5f430ec2060da36adc30ec20708ef7b0f641ef78b7880a15", null ]
    ] ],
    [ "Logger", "db/d67/classLogger.html#abc41bfb031d896170c7675fa96a6b30c", null ],
    [ "getInstance", "db/d67/classLogger.html#a56defd0fd628ce6263d25d02296e48ce", null ],
    [ "getLevelString", "db/d67/classLogger.html#a6910ce52ea9fea16c4e5f65a7e0b413a", null ],
    [ "logMessage", "db/d67/classLogger.html#abb8ffb86dc797039365553568bec7260", null ],
    [ "setLogLevel", "db/d67/classLogger.html#a76737728e58470cc99536839d6fbd631", null ],
    [ "currentLogLevel", "db/d67/classLogger.html#a99832e5af6ef38f457a66216cabec91a", null ]
];